# International - APAC Expansion Notes

**Territory Manager:** Yuki Tanaka  
**Coverage:** Asia Pacific (Japan, Korea, Singapore, Australia, SEA)  
**Date:** January 2, 2026

## Q4 Performance

APAC delivered $57,490 in Q4, hitting 108% of quota. Japan remains our anchor, but we're seeing promising growth in Australia and Singapore.

### Q4 Revenue by Country

| Country | Revenue | YoY Growth |
|---------|---------|------------|
| Japan | $28,550 | +45% |
| Australia | $19,360 | +120% |
| Singapore | $18,690 | +85% |
| South Korea | $10,880 | +60% |
| Other SEA | - | New market |

## Notable Deals

### Tokyo Trading Co - $8,960 (November)
Business tier expansion. They added their entire supply chain division after successful pilot with corporate. Strong reference for Japanese enterprise market.

### Sydney Mining Ltd - $19,360 (December)
Major win in Australian mining sector. Remote site operations need reliable sync, and our bandwidth optimization is a differentiator. First mining customer - opens a new vertical.

### Singapore FinTech Ltd - $18,690 (November)
Fast-growing fintech company. They evaluated several options and chose us for compliance capabilities. Singapore government is pushing financial data regulations, which is driving demand.

### Seoul Electronics - $10,880 (December)
Korean electronics manufacturer. Hybrid deployment for R&D facilities. Took 8 months to close - Korean procurement is thorough.

## Market Insights

### Japan
- Relationships matter enormously - invest in face-to-face
- Local support (Japanese-speaking) is essential
- Long sales cycles but very loyal once won
- Data residency becoming more important

### Australia  
- Mining and resources is a greenfield opportunity
- Government sector opening up (data sovereignty requirements)
- Time zone challenges for support (we need APAC support hours)

### Singapore
- Financial hub - compliance is top priority
- Regional HQ market - win in Singapore, expand to SEA
- English-speaking makes it easier entry point

### South Korea
- Intense competition from local vendors
- Need local partner presence
- Quality and reliability trump price

## Challenges & Requests

1. **Support hours** - We desperately need APAC timezone support. Customers complain about 12+ hour response times for urgent issues.

2. **Data center in APAC** - Japan and Australia both have data residency concerns. Currently we route through US or EU. Request to prioritize APAC DC.

3. **Local currency billing** - Japan especially wants to pay in JPY. Current USD-only billing is friction.

4. **Marketing localization** - Need Japanese and Korean materials. English-only doesn't cut it.

## Q1 Focus

- Close pending Japan enterprise deal ($40K)
- Expand Sydney Mining relationship (sister companies interested)
- Build Singapore government pipeline
- Explore Indonesia opportunity (large market, minimal competition)

## Bottom Line

APAC is the growth story. With proper investment (support, data center, localization), we can double this region in FY27. The fundamentals are strong.
