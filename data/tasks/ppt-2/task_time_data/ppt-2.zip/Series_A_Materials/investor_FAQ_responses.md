# NexusAI - Investor FAQ
## Prepared for Series A Conversations

### Company & Product

**Q: What does NexusAI do in one sentence?**
A: NexusAI uses artificial intelligence to help mid-market companies predict demand, optimize inventory, and prevent supply chain disruptions before they happen.

**Q: What's your unfair advantage?**
A: Three things: (1) Our proprietary demand forecasting model trained on 4 years of cross-industry data achieves 94% accuracy vs. industry average of 65%; (2) We're the only solution that combines forecasting, inventory optimization, AND predictive maintenance in one platform; (3) Our team built the supply chain ML systems at [Major Tech Co] and [Major Retailer].

**Q: Why now? Why didn't this exist before?**
A: Three converging forces: (1) Post-pandemic, companies finally understand supply chain is existential, not just operational; (2) ML models only became accurate enough for production SCM use in the last 2 years; (3) Cloud infrastructure costs dropped 60% making real-time optimization economically viable.

**Q: Who are your competitors?**
A: We see three categories: (1) Legacy giants (SAP, Oracle) - powerful but AI is bolted-on, not native; (2) Pure-play AI (Kinaxis, Coupa) - strong but focused on enterprise, we own mid-market; (3) Point solutions - we're full-stack, they're features.

### Traction & Metrics

**Q: What's your current traction?**
A: As of December 2025:
- 23 paying enterprise customers
- $4.8M ARR (up from $1.2M start of year - 4x growth)
- 97% gross revenue retention
- 118% net revenue retention
- Average contract value: $208,700

**Q: What's your growth rate?**
A: We've grown ARR 4x in 2025. Pipeline suggests 3x growth achievable in 2026, which would put us at ~$14M ARR.

**Q: What's your burn rate and runway?**
A: Current burn is $380K/month. With $2.1M remaining from seed, we have ~5.5 months runway. Series A will extend to 24+ months.

**Q: What are your unit economics?**
A: 
- CAC: $45,000 (blended)
- LTV: $625,000 (based on 3-year average life, 97% retention)
- LTV:CAC ratio: 13.9x
- Payback period: 8 months
- Gross margin: 82%

**Q: Who are your biggest customers?**
A: Can't name without permission, but:
- Fortune 500 food & beverage manufacturer (largest, $480K ACV)
- Major regional grocery chain (18 states, $320K ACV)
- Industrial equipment manufacturer (publicly traded, $275K ACV)
- Fast-growing DTC brand (you'd recognize the name, $185K ACV)

### Market

**Q: How big is the market?**
A: 
- TAM: $52B by 2030 (AI-powered supply chain software)
- SAM: $15.3B (our target geographies, verticals, company sizes)
- SOM: $122M by 2030 (realistic capture at <1% market share)

**Q: Why mid-market?**
A: Mid-market ($100M-$1B revenue companies) is underserved. They have enterprise-level complexity but can't afford SAP/Oracle implementations. They're stuck on spreadsheets and legacy systems. We give them Fortune 500 capabilities at 1/10th the cost.

### Team

**Q: Tell me about the founding team.**
A: 
- **Maya Rodriguez, CEO**: 12 years supply chain, led SCM product at [Major Retailer], MBA Stanford
- **David Park, CTO**: Built ML infrastructure at [Major Tech Co], CS PhD MIT, 3 patents in predictive modeling
- **James Liu, VP Engineering** (joined Q3): 15 years building enterprise SaaS, former VP Eng at [Unicorn]
- **Rachel Foster, VP Sales** (joined Q4): Scaled revenue 0-$50M at two supply chain startups

**Q: What's your team size?**
A: 34 FTEs as of January 2026:
- Engineering: 18
- Sales & Marketing: 8
- Customer Success: 5
- G&A: 3

### Financials & Fundraise

**Q: What are you raising and at what valuation?**
A: We're raising $12M Series A at $48M pre-money valuation ($60M post). This implies ~8x forward ARR multiple based on our 2026 target.

**Q: How will you use the funds?**
A: 
- 50% Engineering (hire to 35, accelerate product roadmap)
- 30% Sales & Marketing (hire to 18, brand building)
- 15% Customer Success (scale for enterprise support)
- 5% G&A

**Q: What milestones will this get you to?**
A: Series A gets us to:
- $32M ARR (target for Series B in 24 months)
- 75 enterprise customers
- International expansion (UK, Germany)
- Platform: Add supplier risk module, sustainability tracking

**Q: What's your path to profitability?**
A: We could be cash-flow positive at ~$25M ARR if we stopped investing in growth. But the market opportunity warrants continued investment. We project profitability at ~$80M ARR (2029) if we choose to optimize for it earlier than planned.

### Risks

**Q: What keeps you up at night?**
A: Honestly? (1) A big player like Salesforce making a serious AI-SCM acquisition; (2) Hiring senior enterprise sales talent fast enough; (3) Making sure our ML models stay ahead as more training data becomes available to competitors.

**Q: What if there's a recession?**
A: Supply chain software is actually counter-cyclical in many ways. When budgets tighten, efficiency matters more. Our customers typically see 15-25% cost reduction, making us easy to justify. In 2024's mini-slowdown, we saw sales cycles lengthen but win rates actually improved.

---
*Last updated: January 5, 2026*
*For internal use in investor conversations - do not distribute*
