# Q4 Sales Data Export - Data Dictionary

## Overview
This folder contains Q4 FY26 (October - December 2025) sales transaction data exported from Salesforce on January 2, 2026.

## Files

### transactions_[month].csv
Monthly transaction records with the following fields:

| Field | Type | Description |
|-------|------|-------------|
| transaction_id | String | Unique transaction identifier (TXN-XXXXX) |
| date | Date | Transaction close date (YYYY-MM-DD) |
| region | String | Sales region (West, East, Central, International) |
| rep_name | String | Sales representative name |
| customer_name | String | Customer company name |
| product_category | String | Product tier (Essentials, Business, Enterprise) |
| product_name | String | Full product name |
| quantity | Integer | Number of seats/licenses sold |
| unit_price | Decimal | Price per seat (may vary due to discounts) |
| total_amount | Decimal | Total deal value (quantity * unit_price) |
| deal_type | String | New, Expansion, or Renewal |

### returns_q4.csv
Return/refund records for Q4:

| Field | Type | Description |
|-------|------|-------------|
| return_id | String | Unique return identifier (RTN-XXXX) |
| original_transaction_id | String | Reference to original transaction |
| return_date | Date | Date return was processed |
| region | String | Sales region |
| customer_name | String | Customer company name |
| product_category | String | Product tier |
| quantity_returned | Integer | Seats returned |
| refund_amount | Decimal | Total refund value |
| return_reason | String | Customer-stated reason |
| resolution_status | String | Current status of return |

## Notes
- All amounts are in USD
- Enterprise pricing is negotiated; unit prices vary by deal
- International transactions are in USD equivalent (converted at time of close)
- Returns data includes only processed returns; pending returns not included

## Questions?
Contact: data-ops@cloudsyncsolutions.com
