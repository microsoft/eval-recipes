***********
Simulations
***********

.. currentmodule:: graspologic.simulations



.. autofunction:: er_np

.. autofunction:: er_nm

.. autofunction:: sbm

.. autofunction:: rdpg

.. autofunction:: er_corr

.. autofunction:: sbm_corr

.. autofunction:: rdpg_corr

.. autofunction:: mmsbm

