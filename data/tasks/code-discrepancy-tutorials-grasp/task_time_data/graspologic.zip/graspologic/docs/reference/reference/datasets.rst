Datasets
========

.. currentmodule:: graspologic.datasets

Drosophila larval mushroom body
-------------------------------

.. autofunction:: load_drosophila_left

.. autofunction:: load_drosophila_right

Duke mouse whole-brain connectomes
----------------------------------

.. autofunction:: load_mice