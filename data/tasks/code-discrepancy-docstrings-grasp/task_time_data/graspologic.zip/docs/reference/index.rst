..  -*- coding: utf-8 -*-

.. toctree::
   :maxdepth: 1

   install
   cli
   contributing
   in-the-wild
   release
   reference/index

