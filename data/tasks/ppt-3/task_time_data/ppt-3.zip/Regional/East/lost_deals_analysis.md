# East Region - Q4 Lost Deals Analysis

**Prepared by:** Sarah Williams  
**Date:** January 3, 2026

## Summary

Lost 6 competitive deals in Q4 totaling approximately $67,000 in potential revenue. While our win rate improved from Q3 (went from 58% to 71%), these losses reveal patterns we need to address.

## Lost Deals Detail

### 1. New York Media Corp - Est. $22,000
**Lost to:** Bundled productivity suite  
**Stage Lost:** Final negotiation  
**Analysis:**
Customer's CFO mandated using existing productivity suite tools to avoid "adding another vendor." Our technical champion tried to make the case but couldn't overcome the CFO's cost consolidation initiative.

**Lesson:** Need executive-level messaging around why best-of-breed beats bundled.

---

### 2. Boston University System - Est. $18,000
**Lost to:** Educational discount from competitor  
**Stage Lost:** Pricing  
**Analysis:**
Competitor offered 40% educational discount vs. our 15%. Product evaluation favored us, but budget couldn't stretch. This is a pricing/discounting policy issue.

**Lesson:** Review educational pricing strategy.

---

### 3. Philadelphia Law Firm - Est. $12,000
**Lost to:** No decision  
**Stage Lost:** Evaluation  
**Analysis:**
Deal stalled when our champion left the company. New contact didn't see urgency. Classic "no decision" loss.

**Lesson:** Multi-thread relationships earlier.

---

### 4. Georgia Manufacturing - Est. $8,000
**Lost to:** Legacy vendor  
**Stage Lost:** Final decision  
**Analysis:**
CIO wanted to switch, but plant managers pushed back on "another change." Existing vendor offered steep renewal discount to retain.

**Lesson:** Need change management support offerings.

---

### 5. Connecticut Insurance - Est. $5,000
**Lost to:** Internal build  
**Stage Lost:** Early evaluation  
**Analysis:**
IT team decided to build their own sync solution. Unusual, but they had resources. We'll follow up in 6 months when they realize the maintenance burden.

---

### 6. Virginia Tech Startup - Est. $2,000
**Lost to:** Free tier of competitor  
**Stage Lost:** Pricing  
**Analysis:**
Early-stage startup couldn't justify paid solution when competitor offers generous free tier. Not really our target market anyway.

## Loss Themes

| Reason | Count | Est. Revenue Lost |
|--------|-------|-------------------|
| Bundled suite / cost consolidation | 1 | $22,000 |
| Competitor pricing/discounting | 2 | $20,000 |
| No decision / champion loss | 1 | $12,000 |
| Incumbent retention | 1 | $8,000 |
| Build vs. buy | 1 | $5,000 |

## Recommendations

1. **Executive value messaging** - CFO-ready content on total cost, not just license cost
2. **Educational pricing review** - Consider matching competitor discounts for strategic accounts
3. **Champion continuity** - Earlier multi-threading in enterprise deals
