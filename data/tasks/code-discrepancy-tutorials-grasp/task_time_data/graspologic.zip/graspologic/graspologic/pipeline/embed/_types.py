from typing import Union

import networkx as nx

NxGraphType = Union[nx.Graph, nx.DiGraph]
