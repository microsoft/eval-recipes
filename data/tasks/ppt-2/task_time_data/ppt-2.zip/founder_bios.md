# NexusAI Leadership Team

## Founders

### Maya Rodriguez - Co-Founder & CEO

Maya brings 12 years of supply chain expertise to NexusAI. Most recently, she led Product Management for Supply Chain Systems at RetailGiant, where she oversaw $2B+ in inventory optimization initiatives and managed a team of 25 product managers.

**Background:**
- VP Product, Supply Chain @ RetailGiant (2019-2023)
- Sr. Director, Operations @ LogiFlow Inc (2015-2019)
- Supply Chain Consultant @ McKinsey (2011-2015)

**Education:**
- MBA, Stanford Graduate School of Business (2011)
- BS Industrial Engineering, Georgia Tech (2007)

**Notable Achievements:**
- Led implementation of ML-based demand forecasting that reduced overstock by 34%
- Named to "40 Under 40 in Supply Chain" by Supply Chain Digest (2022)
- Holder of 2 patents in inventory optimization algorithms

---

### David Park - Co-Founder & CTO

David is a machine learning expert with deep experience building production AI systems at scale. At TechCorp, he architected the ML infrastructure that powers real-time recommendations for 400M+ users.

**Background:**
- Principal Engineer, ML Infrastructure @ TechCorp (2016-2023)
- Sr. Research Scientist @ AI Research Lab (2013-2016)
- Software Engineer @ StartupX (acquired) (2010-2013)

**Education:**
- PhD Computer Science (Machine Learning), MIT (2013)
- BS Computer Science, UC Berkeley (2008)

**Notable Achievements:**
- 3 patents in predictive modeling and time-series forecasting
- Published 12 papers in top ML conferences (NeurIPS, ICML, KDD)
- Built TechCorp's demand prediction system (99.2% uptime, $500M+ revenue impact)
- Thesis: "Scalable Approaches to Multi-Horizon Time Series Prediction"

---

## Executive Team

### James Liu - VP Engineering
*Joined September 2025*

James brings 15 years of experience scaling engineering organizations at high-growth SaaS companies. He previously served as VP Engineering at DataPlatform (acquired for $800M), where he grew the team from 20 to 180 engineers.

**Background:**
- VP Engineering @ DataPlatform (2019-2025)
- Engineering Director @ CloudBase (2014-2019)
- Sr. Engineer @ Google (2009-2014)

**Education:**
- MS Computer Science, Carnegie Mellon (2009)
- BS Computer Science, University of Washington (2007)

---

### Rachel Foster - VP Sales
*Joined October 2025*

Rachel has a proven track record of building enterprise sales organizations in the supply chain software space. She scaled revenue from $0 to $50M at two previous startups.

**Background:**
- VP Sales @ SupplyTech (Series B → acquired) (2021-2025)
- Director of Sales @ LogiSoft (2017-2021)
- Enterprise AE @ SAP (2012-2017)

**Education:**
- BA Business Administration, University of Texas Austin (2012)

**Notable Achievements:**
- Closed largest deal in SupplyTech history ($2.4M ACV)
- Built and led team of 22 sales professionals
- Exceeded quota 8 consecutive years

---

### Sarah Chen - VP Finance
*Joined March 2025*

Sarah oversees all financial operations, planning, and investor relations. She brings experience from both startup and growth-stage companies in the enterprise software space.

**Background:**
- Director of Finance @ GrowthSaaS (Series B-D) (2020-2025)
- Finance Manager @ Deloitte (2016-2020)
- Financial Analyst @ Goldman Sachs (2013-2016)

**Education:**
- MBA, Wharton School of Business (2020)
- BS Finance, NYU Stern (2013)
- CPA (California)

---

## Advisory Board

- **Michael Torres** - Former CIO, Fortune 100 Manufacturer
- **Dr. Jennifer Walsh** - Professor of Operations Research, MIT Sloan
- **Robert Kim** - Partner, Top-Tier VC (led Series Seed)
- **Amanda Chen** - Former SVP Supply Chain, Major Retailer

---

## Team Culture

NexusAI has assembled a world-class team united by a shared mission: making enterprise supply chain intelligence accessible to every company, not just the Fortune 500.

**Team Highlights:**
- 34 employees across engineering, sales, marketing, CS, and G&A
- 65% from underrepresented backgrounds in tech
- Remote-first with hubs in San Francisco and Austin
- Average tenure of prior founding team at previous companies: 8 years
- Combined team has shipped ML products used by 500M+ end users

---
*Last updated: January 2026*
