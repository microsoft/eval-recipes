# West Region - Q4 Territory Notes

**Territory Manager:** Marcus Chen  
**Region:** West (CA, OR, WA, AZ, NV, HI, AK)  
**Date:** January 2, 2026

## Q4 Summary

Strong quarter overall. We exceeded quota by 8% driven by two large Enterprise deals in December. The tech sector continues to be our bread and butter, but we're seeing good traction in healthcare and government.

## Key Wins

1. **San Francisco Tech Giants** - $26.4K expansion deal. They started with 200 seats in Q2, now up to 800 total. Champion is their VP of IT who loves the hybrid sync capability. Potential for 2000+ seats in FY27.

2. **San Diego Biotech** - $16.7K new logo. Competitive displacement from a legacy vendor. Compliance automation was the clincher - they were spending 20+ hours/month on manual compliance checks.

3. **Denver Energy Corp** - $12.5K expansion. Originally Essentials customer, upgraded to Enterprise for the SIEM integration.

## Pipeline for Q1

- **Major Healthcare System** (NDA) - 1500 seats, Enterprise. In legal review. Could close Feb.
- **Portland Tech Hub** - Expansion opportunity, adding 300 seats
- **University of California system** - Early stage, but could be massive (10K+ seats)

## Challenges

- Lost 2 deals to bundled suite options ("already paying for it")
- Essentials tier seeing higher churn than expected - customers either upgrade or leave
- Need better competitive positioning against productivity suite vendors

## Team Notes

Lisa Martinez had an excellent quarter - she's really figured out the retail vertical. Recommending her for President's Club consideration.
