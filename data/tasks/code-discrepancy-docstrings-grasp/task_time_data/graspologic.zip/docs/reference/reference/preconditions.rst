Preconditions
=============

.. autofunction:: graspologic.preconditions.check_argument_types
.. autofunction:: graspologic.preconditions.check_optional_argument_types
.. autofunction:: graspologic.preconditions.check_argument
.. autofunction:: graspologic.preconditions.is_real_weighted
