********
Aligning
********

.. currentmodule:: graspologic.align

Sign flips
----------
.. autoclass:: SignFlips

Orthogonal Procrustes
---------------------
.. autoclass:: OrthogonalProcrustes

Seedless Procrustes
-------------------
.. autoclass:: SeedlessProcrustes
