# FY26 Annual Plan - Sales Targets (Excerpt)

**Classification:** Internal Only  
**Version:** Final - Board Approved  
**Date:** September 15, 2025

---

## Revenue Targets

### Total Company

| Quarter | Target | Stretch |
|---------|--------|---------|
| Q1 FY26 | $650,000 | $715,000 |
| Q2 FY26 | $780,000 | $858,000 |
| Q3 FY26 | $850,000 | $935,000 |
| Q4 FY26 | $920,000 | $1,012,000 |
| **FY26 Total** | **$3,200,000** | **$3,520,000** |

### By Region

| Region | FY26 Target | % of Total |
|--------|-------------|------------|
| East | $1,120,000 | 35% |
| West | $960,000 | 30% |
| International | $640,000 | 20% |
| Central | $480,000 | 15% |

## Product Mix Goals

Target revenue distribution by product tier:

| Tier | Target Mix | Strategic Rationale |
|------|------------|---------------------|
| Enterprise | 55% | Highest margin, lowest churn |
| Business | 35% | Volume tier, expansion path |
| Essentials | 10% | Entry point only |

**Note:** Essentials should primarily serve as a "land" tier for future expansion. Teams should focus on qualifying for Business or Enterprise from the start where possible.

## Key Growth Initiatives

1. **Enterprise Acceleration**
   - Target: 40% YoY growth in Enterprise tier
   - Focus industries: Healthcare, Financial Services, Government
   - Enabler: Compliance automation differentiation

2. **International Expansion**
   - Target: 50% growth in International revenue
   - Key markets: UK, Germany, Japan, Australia
   - Enabler: EU data center, APAC support hours

3. **Vertical Specialization**
   - Develop deep expertise in 3 priority verticals
   - Healthcare, Financial Services, Government
   - Goal: 60% of new logos from priority verticals

## Success Metrics

Beyond revenue, teams will be measured on:

| Metric | Target |
|--------|--------|
| Net Revenue Retention | >110% |
| Logo Retention | >90% |
| Average Deal Size | >$15,000 |
| Enterprise Mix | >50% of new ARR |

## Compensation Notes

- Quota attainment accelerators kick in at 100%
- President's Club qualification: 120%+ of quota
- Quarterly SPIFFs for Enterprise deals >$25K

---

*For full plan details, refer to the FY26 Operating Plan document on SharePoint.*
