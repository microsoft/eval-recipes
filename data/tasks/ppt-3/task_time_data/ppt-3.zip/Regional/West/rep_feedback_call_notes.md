# West Region - Rep Feedback Call
**Date:** December 18, 2025  
**Attendees:** Marcus Chen, Lisa Martinez, Regional Director

---

## Marcus's Feedback

**What's working:**
- "The compliance automation demo is a killer. When I show the automatic PHI detection, security teams get excited. That's what closes Enterprise deals."
- "Hybrid sync resonates with tech companies. They all have some on-prem stuff they can't fully migrate."

**What's not working:**
- "Essentials is hard to sell. The value prop isn't strong enough at that price point. Customers either want Business features or they want something cheaper."
- "We need a better response to 'we already have OneDrive/Google Drive.' I lose deals to this objection even when our product is clearly better."

**Product requests:**
- FedRAMP - "I have 3 government deals stuck waiting for this"
- Better mobile app - "It's functional but not great"

---

## Lisa's Feedback

**What's working:**
- "Retail vertical is taking off. They love the unlimited storage for store footage and POS data."
- "The migration service messaging is strong. Customers are scared of switching costs, and when we say 'we handle everything,' it removes a major objection."

**What's not working:**
- "Returns are eating into my numbers. Had 3 Essentials customers bail in Q4."
- "The 50-seat minimum on Essentials is awkward. Lost a few smaller deals."

**Product requests:**
- Lower seat minimum for Essentials (25 seats?)
- Retail-specific case studies

---

## Action Items
1. [ ] Escalate Essentials feedback to product team
2. [ ] Request retail case studies from marketing
3. [ ] Schedule competitive training on productivity suite objections
