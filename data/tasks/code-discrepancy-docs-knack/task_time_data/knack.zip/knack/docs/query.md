Query
=====

Query support is provided through [JMESPath](http://jmespath.org).

This allows filter and project of command output.
