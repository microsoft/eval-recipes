Inference
=========

.. currentmodule:: graspologic.inference

Two-graph hypothesis testing
----------------------------

.. autofunction:: density_test

.. autofunction:: group_connection_test

.. autofunction:: latent_position_test

.. autofunction:: latent_distribution_test
