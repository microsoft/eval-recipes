Matching
========

.. currentmodule:: graspologic.match

Graph Matching
--------------------
.. autofunction:: graph_match
