# Q4 Stretch Goals - Executive Memo

**From:** VP of Sales  
**To:** Regional Managers  
**Date:** October 1, 2025  
**Subject:** Q4 Push - Stretch Goals and Incentives

---

Team,

We're entering Q4 with good momentum. If we can push hard this quarter, we have a real shot at hitting our stretch target of $1,012,000 (10% above plan).

## Why It Matters

- Board visibility on FY26 performance
- Sets us up for aggressive FY27 planning
- Funding for additional headcount tied to stretch achievement
- Personal upside for all of you

## Stretch Incentives

In addition to standard accelerators, I'm adding Q4-specific incentives:

### Team Level
- If we hit stretch as a company: **$25,000 bonus pool** split among quota-carrying reps
- If individual region hits 115%+: additional **$5,000** to that team

### Individual Level  
- Largest Enterprise deal in Q4: **$3,000 bonus**
- Most new logos in Q4: **$2,000 bonus**
- Highest attainment over 100%: **$2,500 bonus**

### President's Club Update
- Anyone hitting 125% in Q4 automatically qualifies for President's Club (normally requires 120% annual)

## Focus Areas

To hit stretch, prioritize:

1. **Pull in Q1 pipeline** - What deals can realistically close in December?
2. **Expansions** - Fastest path to revenue. Who's ready for more seats?
3. **Enterprise focus** - One $30K deal > six $5K deals
4. **December push** - I know holidays are tough, but Dec 1-20 is critical

## Weekly Reviews

Starting October 7, I'm adding a 30-minute pipeline review each Monday at 8am PT. Come prepared with:
- Top 5 deals expected to close this month
- Blockers and asks
- Expansion opportunities in existing base

## Closing Thought

I know Q4 is always a grind. But we have a strong product, happy customers, and the market is moving our direction. Let's finish the year strong and set ourselves up for an even bigger FY27.

Questions? My door is always open.

---

*Go get 'em.*
