**********
Clustering
**********

.. currentmodule:: graspologic.cluster

K-Means Clustering
------------------
.. autoclass:: KMeansCluster

Gaussian Mixture Models Clustering
----------------------------------
.. autoclass:: GaussianCluster

.. autoclass:: AutoGMMCluster

Hierarchical Clustering
----------------------------------
.. autoclass:: DivisiveCluster
    :no-inherited-members:
