# West Region - Q4 Big Deals Summary

## Deals Over $10K

| Customer | Amount | Category | Rep | Notes |
|----------|--------|----------|-----|-------|
| San Francisco Tech Giants | $26,400 | Enterprise | Marcus Chen | Expansion - added 400 seats |
| San Diego Biotech | $16,720 | Enterprise | Marcus Chen | New logo, competitive win |
| Denver Energy Corp | $12,470 | Enterprise | Lisa Martinez | Upgrade from Essentials |
| Pinnacle Healthcare | $11,250 | Enterprise | Marcus Chen | New logo, Oct close |

## Deal Highlights

### San Francisco Tech Giants (December)
- **Context:** Existing customer since Q2, started with 200 seats
- **Expansion:** Added 400 seats for engineering department
- **Why us:** Hybrid sync critical for their distributed team. CEO personally uses product.
- **Next steps:** Q1 meeting to discuss company-wide rollout (potential 1400 more seats)

### San Diego Biotech (November)
- **Context:** Competitive displacement from legacy vendor
- **Decision drivers:** 
  1. Compliance automation (HIPAA requirements)
  2. Modern UX - legacy system had very dated interface
  3. 30% lower TCO over 3 years
- **Procurement note:** Unusually smooth - CIO had budget authority

### Denver Energy Corp (November)
- **Context:** Started as 100-seat Essentials customer in Q1
- **Upgrade reason:** Needed SIEM integration for SOC compliance
- **Land and expand working:** This validates our Essentials -> Enterprise path

## Lost Deals Over $10K

| Customer | Est. Value | Lost To | Reason |
|----------|-----------|---------|--------|
| Oregon State Gov | $18,000 | Productivity suite | "Already paying for it" |
| Sacramento Health | $14,000 | Legacy vendor | Existing relationship, risk aversion |

## Observations

1. Enterprise tier is where the money is - 4 deals = 68% of region revenue
2. Compliance automation is our strongest differentiator
3. Need better story for "already have productivity suite" objection
