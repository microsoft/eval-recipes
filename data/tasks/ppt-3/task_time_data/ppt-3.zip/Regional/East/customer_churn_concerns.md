# East Region - Customer Churn Concerns

**CONFIDENTIAL - Internal Only**  
**Author:** Sarah Williams  
**Date:** December 28, 2025

## Overview

I'm flagging some concerning patterns in our East region customer base. While our new business is strong, we're seeing early warning signs of churn that could impact Q1 and beyond.

## At-Risk Accounts

### HIGH RISK

**1. Pittsburgh Steel Works** (already churned)
- **Original deal:** $1,170 (65 seats Essentials)
- **Status:** Refund processed December 2025
- **Reason:** Integration issues with their legacy ERP system
- **Post-mortem:** We oversold ease of integration. Their ERP is ancient and our standard connectors didn't work. Custom integration quote ($15K) was more than they wanted to spend.

**2. Atlantic Financial** (expansion customer showing churn signals)
- **Current ARR:** ~$4,800
- **Warning signs:** 
  - Usage dropped 40% in November
  - Champion hasn't responded to last 2 emails
  - Heard they're evaluating productivity suite bundled option
- **Action needed:** Executive outreach ASAP

### MEDIUM RISK

**3. NYC Media Holdings**
- **Current ARR:** ~$3,840
- **Warning signs:**
  - Asked about contract cancellation terms
  - New CTO started (no relationship)
- **Action needed:** Schedule QBR with new CTO

**4. Rhode Island Medical**
- **Current ARR:** ~$3,520
- **Warning signs:**
  - Slow adoption (only 60% of seats activated)
  - Support tickets about "confusing interface"
- **Action needed:** Customer success intervention

## Patterns

The concerning theme: **Essentials and lower Business customers are churning at higher rates than Enterprise.** This makes sense - Enterprise customers get dedicated TAM, QBRs, and proactive support. Smaller customers often feel ignored.

## Churn by Tier (East Region)

| Tier | Q4 Churn Rate | Revenue Impact |
|------|---------------|----------------|
| Essentials | 18% | -$2,340 |
| Business | 6% | -$3,840 (if Atlantic leaves) |
| Enterprise | 0% | $0 |

## Recommendations

1. **Customer success for mid-market** - We need some level of proactive engagement for Business tier, not just Enterprise
2. **Onboarding improvements** - Low adoption often precedes churn
3. **Better integration assessment** - Don't sell to customers where integration will be problematic
4. **Executive sponsor program** - Early warning system when champions leave

## My Concern

If we don't address mid-market churn, we're building on sand. Our Enterprise business is solid, but the funnel from Essentials -> Business -> Enterprise is leaking.

This is a company-wide issue, not just East. I've compared notes with Marcus (West) and Robert (Central) - they're seeing similar patterns.

Worth raising to leadership.
