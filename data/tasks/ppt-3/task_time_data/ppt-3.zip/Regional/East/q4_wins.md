# East Region - Q4 Wins Summary

**Territory Manager:** Sarah Williams  
**Region:** East (NY, NJ, PA, MA, CT, MD, VA, DC, FL, GA)  
**Quarter:** Q4 FY26

## Headline Numbers

- **Total Revenue:** $298,160 (highest in company)
- **Quota Attainment:** 112%
- **New Logos:** 12
- **Expansions:** 4
- **Renewals:** 3

## Top 5 Deals

### 1. DC Government Services - $32,000
**Category:** Enterprise | **Seats:** 800 | **Rep:** Jennifer Park

Massive win against two entrenched competitors. This is a new federal contractor that needed compliant file sync. Our compliance automation and pending FedRAMP were key differentiators. This opens the door to other federal contractors in the DC area.

### 2. New York Financial Services - $31,500  
**Category:** Enterprise | **Seats:** 750 | **Rep:** Sarah Williams

Financial services is becoming a strong vertical for us. The customer was frustrated with their legacy vendor's slow response times. Our 24/7 support SLA sealed the deal. Potential for 2x expansion as they consolidate from multiple tools.

### 3. Maryland Defense Systems - $29,050
**Category:** Enterprise | **Seats:** 700 | **Rep:** Jennifer Park

Another defense contractor win. Jennifer is building a great pipeline in this vertical. The hybrid deployment option was critical - they cannot put certain data in public cloud.

### 4. Tampa Healthcare System - $25,420
**Category:** Enterprise | **Seats:** 620 | **Rep:** Sarah Williams

HIPAA compliance automation was the hero feature. They were spending significant staff time on manual compliance checks. ROI story wrote itself.

### 5. Charlotte Banking Corp - $23,375
**Category:** Enterprise | **Seats:** 550 | **Rep:** Jennifer Park

Competitive displacement from a consumer-origin vendor. Customer felt they had "outgrown" the less enterprise-focused solution. Our delegated admin features were a key differentiator.

## Patterns & Insights

1. **Enterprise is our sweet spot** - 8 of top 10 deals were Enterprise tier
2. **Compliance sells** - Every major win mentioned compliance as top 3 decision factor
3. **Government/Defense emerging** - Jennifer's focus here is paying off
4. **Financial services opportunity** - NYC market is underpenetrated

## Q1 Pipeline Highlights

- Major NYC bank (NDA) - 1200 seats, deep in procurement
- Boston hospital system - 900 seats, demo scheduled Jan 15
- Florida state agency - 600 seats, pending budget approval
