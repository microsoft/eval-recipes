Nomination
==========

.. currentmodule:: graspologic.nominate

Spectral Vertex Nomination
---------------------------------------

.. autoclass:: SpectralVertexNomination

Vertex Nomination via SGM
-------------------------
.. autoclass:: VNviaSGM
