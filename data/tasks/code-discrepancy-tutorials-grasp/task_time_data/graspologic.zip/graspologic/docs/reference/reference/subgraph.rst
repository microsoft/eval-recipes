Subgraph
========

.. currentmodule:: graspologic.subgraph

Signal-Subgraph Estimators
--------------------------

.. autoclass:: SignalSubgraph
