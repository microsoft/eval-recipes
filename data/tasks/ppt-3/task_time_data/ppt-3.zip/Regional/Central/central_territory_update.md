# Central Region - Q4 Territory Update

**Territory Manager:** Robert Johnson  
**Region:** Central (TX, IL, OH, MI, MN, WI, MO, IN, KS, NE, IA)  
**Date:** January 2, 2026

## Q4 Performance Summary

Challenging quarter for Central. We finished at 78% of quota, primarily due to higher-than-expected churn and some deals slipping to Q1. The region is traditionally slower in Q4 due to budget cycles in manufacturing (our largest vertical).

### Key Metrics

| Metric | Q4 Actual | Q4 Target | Variance |
|--------|-----------|-----------|----------|
| New Revenue | $35,730 | $46,000 | -22% |
| Churned Revenue | $6,660 | $2,000 | +233% |
| Net Revenue | $29,070 | $44,000 | -34% |
| New Logos | 8 | 10 | -20% |

## What Happened

### The Good

1. **Dallas Oil & Gas** ($6,400) - Nice Business tier win in energy sector. They're expanding operations and needed compliant file sync for field offices.

2. **Nashville Entertainment** ($5,600) - Good expansion deal. They love the unlimited storage for media files.

3. **St. Louis Healthcare** ($5,760) - Expansion from Essentials to Business. The compliance automation drove the upgrade.

### The Bad

**Churn hit us hard this quarter:**

- Midwest Manufacturing ($1,350) - Product didn't meet their requirements. In hindsight, we shouldn't have sold to them - their use case was edge.
- Chicago Legal Partners ($900) - Lost to competitor with better legal-specific features
- Kansas City Foods ($1,620) - Company restructuring, they cut costs across the board
- Ohio Manufacturing ($990) - Switched to bundled productivity suite
- Milwaukee Brewing Co ($900) - Decided to stay with existing solution

**Pattern:** All churned accounts were Essentials tier. We need to have a serious conversation about Essentials viability.

### Deals Slipped to Q1

- **Major auto manufacturer** (NDA) - $45K deal, was supposed to close Dec 15. Legal found an issue with our data processing agreement. Working through it, expect Jan close.
- **Chicago hospital system** - $22K deal, budget freeze delayed. Green-lighted for Q1.

These two deals alone would have put us over quota.

## Regional Challenges

1. **Manufacturing seasonality** - Q4 is tough; budgets are locked, plants are doing inventory
2. **Essentials tier weakness** - We're essentially selling against "free" (bundled suites) with Essentials
3. **Limited enterprise pipeline** - Most of our deals are Business tier; we need bigger logos
4. **Geography** - Lots of travel required; territory is spread out

## Q1 Outlook

With the two slipped deals, Q1 looks much better. Also have several opportunities warming up:

- Auto manufacturer (mentioned above) - $45K
- Chicago hospital system - $22K
- Indianapolis insurance company - $15K
- Detroit tech startup - $8K

If we close the slipped deals plus one of the new ones, we'll be tracking well.

## Ask

1. **Review Essentials strategy** - I don't think it's working in Central. Can we discuss?
2. **More marketing support** - Need help generating enterprise pipeline
3. **Consider regional specialist** - Central is huge and diverse; hard to cover with just me

---

*Happy to discuss any of this in the Q4 review meeting.*
