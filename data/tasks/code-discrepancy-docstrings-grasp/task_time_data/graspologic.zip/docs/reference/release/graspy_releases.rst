GraSPy Release Log
==================

GraSPy 0.3
----------
Release date: 04 Aug 2020
Supports Python 3.6, and 3.7

.. toctree::
   :maxdepth: 1

   release_0.3.rst

GraSPy 0.2
----------
Release date: 02 Mar 2020
Supports Python 3.5, 3.6, and 3.7

.. toctree::
   :maxdepth: 1

   release_0.2.rst

GraSPy 0.1
----------
Release date: 05 Aug 2019
Supports Python 3.5, 3.6, and 3.7

.. toctree::
   :maxdepth: 1

   release_0.1.rst

GraSPy 0.0.3
------------
Release date: 11 June 2019
Supports Python 3.5, 3.6, and 3.7.

.. toctree::
   :maxdepth: 1

   release_0.0.3.rst

GraSPy 0.0.2
------------
Release date: 26 March 2019
Supports Python 3.5, 3.6, and 3.7.

.. toctree::
   :maxdepth: 1

   release_0.0.2.rst

GraSPy 0.0.1
------------
Release date: 14 December 2018
Supports Python 3.5, 3.6, and 3.7.

.. toctree::
   :maxdepth: 1

   release_0.0.1.rst
