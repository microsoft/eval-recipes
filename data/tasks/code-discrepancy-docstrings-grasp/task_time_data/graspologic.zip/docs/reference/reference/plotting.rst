********
Plotting
********

.. currentmodule:: graspologic.plot

Heatmap
-------
.. autofunction:: heatmap

Gridplot
--------
.. autofunction:: gridplot

Pairplot
--------
.. autofunction:: pairplot
.. autofunction:: pairplot_with_gmm

Degreeplot
----------
.. autofunction:: degreeplot

Edgeplot
--------
.. autofunction:: edgeplot

Screeplot
---------
.. autofunction:: screeplot

Adjplot
-------
.. autofunction:: adjplot

Matrixplot
----------
.. autofunction:: matrixplot
