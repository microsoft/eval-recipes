# IT Support Ticket #4892

**Status:** Open  
**Priority:** Low  
**Submitted by:** David Kim  
**Date:** December 18, 2025  
**Assigned to:** Kevin O'Brien

---

## Issue Description

My external monitor (the Dell 27" on the left side) keeps flickering intermittently. Started about a week ago. Happens maybe 2-3 times per hour, lasts for about 5 seconds each time.

## Details

- Monitor model: Dell U2722D
- Connected via: USB-C hub
- Laptop: ThinkPad X1 Carbon Gen 11
- Other monitor (right side): Working fine
- Tried different USB-C port: Same issue
- Tried direct connection (no hub): Haven't tried yet

## Troubleshooting Attempted

1. Restarted laptop - no change
2. Updated display drivers - no change
3. Checked cable connection - seems secure
4. Tried lowering refresh rate from 60Hz to 59Hz - might be slightly better?

## Notes

Not urgent - I can live with it, just annoying. Please fix when you have a chance.

If you need to look at my setup in person, afternoons are better. I have meetings most mornings.

---

## IT Response (Kevin, Dec 20)

Hi David,

A few things to try:

1. Please try a direct connection (bypass the hub) and let me know if the issue persists
2. Check if there's a firmware update available for your hub
3. The intermittent nature suggests it might be a cable issue - I can drop off a new USB-C cable for you to test

If none of that works, we might need to swap the monitor. Let me know.

---

## Follow-up (David, Dec 23)

Kevin - tried direct connection, still flickering. But less frequently maybe? Hard to tell. Let's swap the monitor after the holidays. Not urgent.

Out of office Dec 24 - Jan 2. Happy holidays!
